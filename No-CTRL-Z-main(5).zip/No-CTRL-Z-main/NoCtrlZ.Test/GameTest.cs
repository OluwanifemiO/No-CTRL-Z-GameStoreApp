using NoCtrlZ;
using NoCtrlZ.Controllers;
using NoCtrlZ.Entities;
using Moq;
using System.Reflection.Metadata;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Azure;
using Microsoft.AspNetCore.Http;
using System.Diagnostics.Metrics;
using System.Linq;
using Microsoft.Net.Http.Headers;
using System.Net;
using Microsoft.Extensions.Options;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Amazon.SimpleEmail.Model;

namespace NoCtrlZ.Test
{
    public class GameTest
    {
        NoCtrlZDbContext _context;
        GameController _gameController;
        WishListController _wishListController;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<NoCtrlZDbContext>()
            .UseInMemoryDatabase(databaseName: "NoContrlZ")
            .Options;

            _context = new NoCtrlZDbContext(options);
            _gameController = new GameController(_context);
            _wishListController = new WishListController(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Database.EnsureDeleted();
        }

        [Test]
        [TestCase("call")]
        public async Task GetGameList_Search_ReturnGameList(string search)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };


            List<Game> games = new List<Game>()
            {
                new Game()
                {
                    GameId = 1,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game()
                {
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
            };


            members.ForEach((m) => _context.Members.Add(m));
            _context.SaveChanges();

            // Act
            var result = _gameController.Index(search) as ViewResult;

            // Assert
            List<Game> expectedGames = games.Where(g => g.Name.Contains(search)).ToList();
            List<Game> actualGames = result.Model as List<Game>;
            Assert.That(actualGames, Is.EqualTo(expectedGames));
        }

        [Test]
        public async Task GetGameList_ReturnGameList()
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };


            List<Game> games = new List<Game>()
            {
                new Game()
                {
                    GameId = 1,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game()
                {
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
            };


            members.ForEach((m) => _context.Members.Add(m));
            games.ForEach((m) => _context.Games.Add(m));
            _context.SaveChanges();

            // Act
            var result = _gameController.Index("") as ViewResult;

            // Assert
            List<Game> expectedGames = games.ToList();
            List<Game> actualGames = result.Model as List<Game>;
            Assert.That(actualGames, Is.EqualTo(expectedGames));
        }

        [Test]
        [TestCase(1, 1)]
        public async Task AddGameToWishList_GameIdAndMemberId_ReturnWishList(int gameId, int memberId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };


            List<Game> games = new List<Game>()
            {
                new Game()
                {
                    GameId = gameId,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game()
                {
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
            };


            members.ForEach((m) => _context.Members.Add(m));
            games.ForEach((m) => _context.Games.Add(m));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _gameController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _gameController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            // Act
            var result = _gameController.AddToWishlist(gameId) as ViewResult;

            // Assert
            WishlistItem wishlist = _context.WishlistItems.Where((w) => w.MemberId == memberId && w.GameId == gameId).First();
            Assert.Multiple(() =>
            {
                Assert.That(wishlist.MemberId, Is.EqualTo(memberId));
                Assert.That(wishlist.GameId, Is.EqualTo(gameId));
            });
        }

        [Test]
        [TestCase(1)]
        public async Task GetGameDetail_GameId_ReturnGameDetail(int gameId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };


            List<Game> games = new List<Game>()
            {
                new Game()
                {
                    GameId = 1,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game()
                {
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
            };


            members.ForEach((m) => _context.Members.Add(m));
            games.ForEach((m) => _context.Games.Add(m));
            _context.SaveChanges();

            // Act
            var result = _gameController.Details(gameId) as ViewResult;

            // Assert
            Game expectedGame = games.FirstOrDefault(g => g.GameId == gameId);
            Game actualGames = result.Model as Game;
            Assert.That(actualGames, Is.EqualTo(expectedGame));
        }
    }
}