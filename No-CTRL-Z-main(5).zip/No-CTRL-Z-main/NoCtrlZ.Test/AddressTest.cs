using NoCtrlZ;
using NoCtrlZ.Controllers;
using NoCtrlZ.Entities;
using Moq;
using System.Reflection.Metadata;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Azure;
using Microsoft.AspNetCore.Http;
using System.Diagnostics.Metrics;
using System.Linq;
using Microsoft.Net.Http.Headers;
using System.Net;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Composition;

namespace NoCtrlZ.Test
{
    public class AddressTest
    {
        NoCtrlZDbContext _context;
        AddressesController _addressesController;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<NoCtrlZDbContext>()
            .UseInMemoryDatabase(databaseName: "NoContrlZ")
            .Options;

            _context = new NoCtrlZDbContext(options);
            _addressesController = new AddressesController(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Database.EnsureDeleted();
        }

        [Test]
        [TestCase(1)]
        public async Task GetAddresses_MemberId_ReturnAddresses(int memberId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<Address> addresses = new List<Address>() {
                new Address() { AddressId = 1, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = true, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            addresses.ForEach((a) => _context.Addresses.Add(a));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _addressesController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };

            // Act
            var result = await _addressesController.Index() as ViewResult;

            // Assert
            List<Address> expectedAddress = addresses.Where(a => a.MemberId == memberId).ToList();

            List<Address> actualAddresses = result.Model as List<Address>;
            Assert.That(expectedAddress, Is.EqualTo(actualAddresses));
        }

        [Test]
        [TestCase(1, 1)]
        public async Task ChangeDefaultAddress_AddressId_ReturnAddresses(int memberId, int addressId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<Address> addresses = new List<Address>() {
                new Address() { AddressId = addressId, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = false, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            addresses.ForEach((a) => _context.Addresses.Add(a));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _addressesController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _addressesController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());


            // Act
            var result = await _addressesController.ChangeDefaultAddress(addressId) as ViewResult;

            // Assert
            addresses[addresses.FindIndex(a => a.AddressId == addressId)].IsDefault = true;
            List<Address> expectedAddress = addresses.ToList();

            List<Address> actualAddresses = _context.Addresses.ToList();
            Assert.That(expectedAddress, Is.EqualTo(actualAddresses));
        }

        [Test]
        [TestCase(1, 1)]
        public async Task DeleteAddress_AddressId_ReturnAddresses(int memberId, int addressId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<Address> addresses = new List<Address>() {
                new Address() { AddressId = addressId, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = false, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            addresses.ForEach((a) => _context.Addresses.Add(a));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _addressesController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _addressesController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());


            // Act
            var result = await _addressesController.Delete(addressId) as ViewResult;

            // Assert
            addresses.RemoveAll(a => a.AddressId == addressId);
            List<Address> expectedAddress = addresses.ToList();

            List<Address> actualAddresses = _context.Addresses.ToList();
            Assert.That(expectedAddress, Is.EqualTo(actualAddresses));
        }

        [Test]
        [TestCase(1)]
        public async Task GetAddressDetail_AddressId_ReturnAddress(int addressId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<Address> addresses = new List<Address>() {
                new Address() { AddressId = addressId, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = false, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            addresses.ForEach((a) => _context.Addresses.Add(a));
            _context.SaveChanges();

            // Act
            var result = await _addressesController.Details(addressId) as ViewResult;

            // Assert
            Address expectedAddress = addresses.FirstOrDefault((a) => a.AddressId == addressId);
            Address actualAddresses = _context.Addresses.FirstOrDefault((a) => a.AddressId == addressId);
            Assert.That(expectedAddress, Is.EqualTo(actualAddresses));
        }

        public static object[] MemberIdAddress =
        {
            new object[] { 1, new Address() { AddressId = 2, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = false, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 }},
        };
        [Test]
        [TestCaseSource(nameof(MemberIdAddress))]
        public async Task CreateAddress_Address_ReturnAddresses(int memberId, Address address)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<Address> addresses = new List<Address>() {
                new Address() { AddressId = 1, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = false, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            addresses.ForEach((a) => _context.Addresses.Add(a));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _addressesController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _addressesController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());


            // Act
            var result = await _addressesController.Create(address) as ViewResult;

            // Assert
            addresses.Add(address);
            List<Address> expectedAddress = addresses.ToList();

            List<Address> actualAddresses = _context.Addresses.ToList();
            Assert.That(expectedAddress, Is.EqualTo(actualAddresses));
        }
    }
}