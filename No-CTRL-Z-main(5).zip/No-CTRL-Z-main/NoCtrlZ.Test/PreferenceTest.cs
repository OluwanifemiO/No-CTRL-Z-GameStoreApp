using NoCtrlZ;
using NoCtrlZ.Controllers;
using NoCtrlZ.Entities;
using Moq;
using System.Reflection.Metadata;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Azure;
using Microsoft.AspNetCore.Http;
using System.Diagnostics.Metrics;
using System.Linq;
using Microsoft.Net.Http.Headers;
using System.Net;
using Microsoft.Extensions.Options;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Amazon.SimpleEmail.Model;

namespace NoCtrlZ.Test
{
    public class PreferenceTest
    {
        NoCtrlZDbContext _context;
        PreferenceController _preferenceController;
        ProfileController _profileController;
        
        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<NoCtrlZDbContext>()
            .UseInMemoryDatabase(databaseName: "NoContrlZ")
            .Options;

            _context = new NoCtrlZDbContext(options);
            _preferenceController = new PreferenceController(_context);
            _profileController = new ProfileController(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Database.EnsureDeleted();
        }

        [Test]
        [TestCase(1)]
        public async Task GetPreference_MemberId_ReturnPreference(int memberId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<Preference> preferences = new List<Preference>() {
                new Preference() { PreferenceId = 1, GameCategory = "Action", Language = "English", Platform = "Windows", MemberId = 1 },
            };

            members.ForEach((m) => _context.Members.Add(m));
            preferences.ForEach((p) => _context.Prefernces.Add(p));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _profileController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };

            // Act
            var result = _profileController.EditPreference() as ViewResult;

            // Assert
            Preference expectedPreferences = preferences.FirstOrDefault(a => a.MemberId == memberId);

            Preference actualPreference = result.Model as Preference;
            Assert.That(expectedPreferences, Is.EqualTo(actualPreference));
        }


        [Test]
        [TestCase(1)]
        public async Task EditPreference_MemberId_ReturnPrefernce(int memberId)
        {
            Member member = new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true };
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true }
            };

            List<Preference> preferences = new List<Preference>() {
                new Preference() { PreferenceId = 1, GameCategory = "Action", Language = "English", Platform = "Windows", MemberId = 1 },
            };

            Preference editedPreference = new Preference() { PreferenceId = 1, GameCategory = "Role", Language = "English", Platform = "Windows", MemberId = 1 };

            members.ForEach((m) => _context.Members.Add(m));
            preferences.ForEach((p) => _context.Prefernces.Add(p));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _preferenceController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext,
            };

            _preferenceController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());


            // Act
            var result = _preferenceController.EditPreference(editedPreference);

            // Assert
            Preference expectedPreferences = editedPreference;
            Preference actualPreference = preferences.First();
            Assert.Multiple(() =>
            {
                Assert.That(actualPreference.PreferenceId, Is.EqualTo(expectedPreferences.PreferenceId));
                Assert.That(actualPreference.Language, Is.EqualTo(expectedPreferences.Language));
                Assert.That(actualPreference.GameCategory, Is.EqualTo(expectedPreferences.GameCategory));
                Assert.That(actualPreference.MemberId, Is.EqualTo(expectedPreferences.MemberId));
                Assert.That(actualPreference.Platform, Is.EqualTo(expectedPreferences.Platform));
            });
        }
    }
}