using NoCtrlZ;
using NoCtrlZ.Controllers;
using NoCtrlZ.Entities;
using Moq;
using System.Reflection.Metadata;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Azure;
using Microsoft.AspNetCore.Http;
using System.Diagnostics.Metrics;
using System.Linq;
using Microsoft.Net.Http.Headers;
using System.Net;
using Microsoft.Extensions.Options;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Amazon.SimpleEmail.Model;

namespace NoCtrlZ.Test
{
    public class WishListTest
    {
        NoCtrlZDbContext _context;
        WishListController _wishListController;

        [SetUp]        
        
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<NoCtrlZDbContext>()
            .UseInMemoryDatabase(databaseName: "NoContrlZ")
            .Options;

            _context = new NoCtrlZDbContext(options);
            _wishListController = new WishListController(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Database.EnsureDeleted();
        }

        [Test]
        [TestCase(1)]
        public async Task GetWishList_MemberId_ReturnWishedGameList(int memberId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<WishlistItem> wishlistItems = new List<WishlistItem>()
            {
                new WishlistItem() {WishlistItemId = 1, GameId = 1, MemberId = 1}
            };

            List<Game> games = new List<Game>()
            {
                new Game()
                {
                    GameId = 1,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game()
                {
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
            };


            members.ForEach((m) => _context.Members.Add(m));
            wishlistItems.ForEach((w) => _context.WishlistItems.Add(w));
            games.ForEach((g) => _context.Games.Add(g));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _wishListController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };

            // Act
            var result = _wishListController.Index() as ViewResult;

            // Assert
            var gameIds = _context.WishlistItems
                            .Where(item => item.MemberId == memberId)
                            .ToList().Select(item => item.GameId).ToList();

            var expectedWishedGames = _context.Games
                            .Where(game => gameIds.Contains(game.GameId))
                            .ToList();

            List<Game> actualWishedGames = result.Model as List<Game>;
            Assert.That(actualWishedGames, Is.EqualTo(expectedWishedGames));
        }

        [Test]
        [TestCase(1, 1)]
        public async Task RemoveGameInWishList_MemberIdAndDeletedGameId_ReturnWishedGameList(int memberId, int gameId)
        {
            Setup();
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<WishlistItem> wishlistItems = new List<WishlistItem>()
            {
                new WishlistItem() {WishlistItemId = 1, GameId = 1, MemberId = 1}
            };

            List<Game> games = new List<Game>()
            {
                new Game()
                {
                    GameId = gameId,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game()
                {
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
            };


            members.ForEach((m) => _context.Members.Add(m));
            wishlistItems.ForEach((w) => _context.WishlistItems.Add(w));
            games.ForEach((g) => _context.Games.Add(g));

            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _wishListController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };

            // Act
            var result = _wishListController.RemoveFromWishlist(gameId) as ViewResult;

            // Assert
            List<WishlistItem> actualWishedGames = _context.WishlistItems.ToList();

            wishlistItems.RemoveAll(item => item.MemberId == memberId && item.GameId == gameId);
            List<WishlistItem> expectedWishedGames = wishlistItems;

            Assert.That(actualWishedGames, Is.EqualTo(expectedWishedGames));
        }
    }
}