using NoCtrlZ;
using NoCtrlZ.Controllers;
using NoCtrlZ.Entities;
using Moq;
using System.Reflection.Metadata;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Azure;
using Microsoft.AspNetCore.Http;
using System.Diagnostics.Metrics;
using System.Linq;
using Microsoft.Net.Http.Headers;
using System.Net;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace NoCtrlZ.Test
{
    public class FriendFamilyTest
    {
        NoCtrlZDbContext _context;
        FriendsController _friendsController;
        FamiliesController _familyController;

        [SetUp]
        public virtual void Setup()
        {
            var options = new DbContextOptionsBuilder<NoCtrlZDbContext>()
            .UseInMemoryDatabase(databaseName: "NoContrlZ")
            .Options;

            _context = new NoCtrlZDbContext(options);
            _friendsController = new FriendsController(_context);
            _familyController = new FamiliesController(_context);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Database.EnsureDeleted();
        }

        [Test]
        [TestCase(1)]
        public async Task GetFriends_MemberId_ReturnFriendsOfMember(int memberId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FriendList> friendList = new List<FriendList>() {
                new FriendList { FriendListId = 1, FriendId = 2, MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            friendList.ForEach((f) => _context.FriendList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _friendsController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };

            // Act
            var result = await _friendsController.Index() as ViewResult;

            // Assert
            List<Member> expectedFriends = friendList.Where(f => f.MemberId == memberId).Select(f =>
            {
                return members.FirstOrDefault(m => m.MemberId == f.FriendId);
            }).ToList();

            List<Member> actualFriends = result.Model as List<Member>;
            Assert.That(expectedFriends, Is.EqualTo(actualFriends));
        }

        [Test]
        [TestCase(1)]
        public async Task GetFamilies_MemberId_ReturnFamilysOfMember(int memberId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FamilyList> familyList = new List<FamilyList>() {
                new FamilyList { FamilyListId = 1, FamilyId = 2, MemberId = 1 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            familyList.ForEach((f) => _context.FamilyList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _familyController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };

            // Act
            var result = await _familyController.Index() as ViewResult;

            // Assert
            List<Member> expectedFriends = familyList.Where(f => f.MemberId == memberId).Select(f =>
            {
                return members.FirstOrDefault(m => m.MemberId == f.FamilyId);
            }).ToList();

            List<Member> actualFamily = result.Model as List<Member>;
            Assert.That(expectedFriends, Is.EqualTo(actualFamily));
        }

        [Test]
        [TestCase(1, 1)]
        public async Task DeleteFamily_MemberIdAndFamilyId_ReturnFamilysOfMember(int memberId, int familiyId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FamilyList> familyList = new List<FamilyList>() {
                new FamilyList { FamilyListId = 1, FamilyId = familiyId, MemberId = memberId }
            };

            members.ForEach((m) => _context.Members.Add(m));
            familyList.ForEach((f) => _context.FamilyList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _familyController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _familyController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            // Act
            var result = await _familyController.DeleteFamily(familiyId) as ViewResult;

            // Assert
            familyList.Remove(familyList.Find(f => f.MemberId == memberId && f.FamilyId == familiyId));
            
            List<FamilyList> actualFamily = _context.FamilyList.ToList();
            Assert.That(familyList, Is.EqualTo(actualFamily));
        }

        [Test]
        [TestCase(1, 1)]
        public async Task DeleteFriend_MemberIdAndFriendId_ReturnFriendsOfMember(int memberId, int friendId)
        {
            // Arrange
            List<Member> members = new List<Member>()
            {
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true },
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FriendList> friendList = new List<FriendList>() {
                new FriendList { FriendListId = 1, FriendId = friendId, MemberId = memberId }
            };

            members.ForEach((m) => _context.Members.Add(m));
            friendList.ForEach((f) => _context.FriendList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _friendsController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _friendsController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            // Act
            var result = await _friendsController.DeleteFriend(friendId) as ViewResult;

            // Assert
            friendList.Remove(friendList.Find(f => f.MemberId == memberId && f.FriendId == friendId));

            List<FriendList> actualFriend = _context.FriendList.ToList();
            Assert.That(friendList, Is.EqualTo(actualFriend));
        }

        [Test]
        [TestCase(1, 2)]
        public async Task AddFriend_MemberIdAndFriendId_ReturnCreatedWishList(int memberId, int friendId)
        {
            Member friend = new Member() { MemberId = friendId, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true };

            // Arrange
            List<Member> members = new List<Member>()
            {
                friend,
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FriendList> friendList = new List<FriendList>() {
                new FriendList { FriendListId = 1, FriendId = 1, MemberId = 2 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            friendList.ForEach((f) => _context.FriendList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _friendsController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _friendsController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            // Act
            var result = await _friendsController.AddFriend(friendId) as ViewResult;

            // Assert
            FriendList actualFriend = _context.FriendList.FirstOrDefault(a => a.FriendId == friendId && a.MemberId == memberId);
            Assert.IsNotNull(actualFriend);
        }

        [Test]
        [TestCase(1, 2)]
        public async Task AddFamily_MemberIdAndFamilyId_ReturnCreatedWishList(int memberId, int familyId)
        {
            Member family = new Member() { MemberId = familyId, Email = "user2@example.com", Password = "!a123456", Username = "Julia123", FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true };

            // Arrange
            List<Member> members = new List<Member>()
            {
                family,
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FamilyList> familyList = new List<FamilyList>() {
                new FamilyList { FamilyListId = 1, FamilyId = 1, MemberId = 2 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            familyList.ForEach((f) => _context.FamilyList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _familyController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _familyController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            // Act
            var result = await _familyController.AddFamily(familyId) as ViewResult;

            // Assert
            FamilyList actualFamily = _context.FamilyList.FirstOrDefault(a => a.FamilyId == familyId && a.MemberId == memberId);
            Assert.IsNotNull(actualFamily);
        }

        [Test]
        [TestCase(1, "Julia")]
        public async Task SearchFamily_MemberIdAndFamilyName_ReturnFamily(int memberId, string familyName)
        {
            Member friend = new Member() { MemberId = memberId, Email = "user2@example.com", Password = "!a123456", Username = familyName, FirstName = "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true };

            // Arrange
            List<Member> members = new List<Member>()
            {
                friend,
                new Member() { MemberId = 2, Email = "user1@example.com", Password = "!a123456", Username = "Samuel123", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsValidated = true }
            };

            List<FamilyList> familyList = new List<FamilyList>() {
                new FamilyList { FamilyListId = 1, FamilyId = 1, MemberId = 2 }
            };

            members.ForEach((m) => _context.Members.Add(m));
            familyList.ForEach((f) => _context.FamilyList.Add(f));
            _context.SaveChanges();

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers.Add("Cookie", new CookieHeaderValue("memberId", memberId.ToString()).ToString());
            _familyController.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _familyController.TempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            // Act
            var result = await _familyController.Find(familyName) as ViewResult;

            // Assert
            var expectedFamily = result.Model as List<Member>;
            List<Member> actualFamily = _context.Members.Where(m => m.Username.Contains(familyName)).ToList();
            Assert.AreEqual(expectedFamily, actualFamily);
        }
    }
}