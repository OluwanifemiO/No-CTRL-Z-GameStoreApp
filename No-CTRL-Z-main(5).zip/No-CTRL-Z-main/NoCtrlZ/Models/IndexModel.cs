﻿namespace NoCtrlZ.Models
{
    public class IndexModel
    {
        public string CurrentTab { get; set; }

    }
}
