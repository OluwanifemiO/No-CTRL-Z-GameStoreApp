﻿namespace NoCtrlZ.Models
{
    public class Game
    {
        public int ID { get; set; }
        public string? Title { get; set; }
        public string? Genre { get; set; }
    }

}
