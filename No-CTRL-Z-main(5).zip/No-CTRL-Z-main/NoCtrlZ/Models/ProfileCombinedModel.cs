﻿using NoCtrlZ.Entities;

namespace NoCtrlZ.Models
{
    public class ProfileCombinedModel
    {
        public IndexModel IndexModel { get; set; }
        public Member Member { get; set; }
    }
}
