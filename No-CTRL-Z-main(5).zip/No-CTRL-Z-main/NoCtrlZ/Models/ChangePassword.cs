﻿using System.ComponentModel.DataAnnotations;

namespace NoCtrlZ.Models
{
    public class ChangePassword
    {
        [Required(ErrorMessage = "Old password is required")]
        [StringLength(15, ErrorMessage = "Must be between 8 and 15 characters", MinimumLength = 8)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,15}$", ErrorMessage = "Password required at least lowercase, uppercase, special case and number\n Must be between 8 and 15 characters")]
        public string? OldPassword { get; set; }

        [Required(ErrorMessage = "The password is required")]
        [StringLength(15, ErrorMessage = "Must be between 8 and 15 characters", MinimumLength = 8)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,15}$", ErrorMessage = "Password required at least lowercase, uppercase, special case and number\n Must be between 8 and 15 characters")]
        public string? NewPassword { get; set; }
        [Compare(nameof(NewPassword), ErrorMessage = "Confirm password is not matched")]
        public string? ConfirmPassword { get; set; }

    }
}
