﻿namespace NoCtrlZ.Entities
{
    public class Event
    {
        public int EventId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public int EmployeeId { get; set; }
        public List<Member> Members { get; set; } = new();
    }
}
