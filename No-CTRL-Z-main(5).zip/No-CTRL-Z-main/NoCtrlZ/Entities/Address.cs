﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoCtrlZ.Entities
{
    public class Address
    {
        public int AddressId { get; set; }
        public bool IsDefault { get; set; }

        public string? Country { get; set; }

        [Required(ErrorMessage = "The First Name is required")]
        public string? FirstName { get; set; }
        [Required(ErrorMessage = "The Last Name is required")]
        public string? LastName { get; set; }
        [Required(ErrorMessage = "The Phone number is required")]
        [RegularExpression("^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$", ErrorMessage = "Phone number is not valid")]
        public string? PhoneNumber { get; set; }
        [Required(ErrorMessage = "The Street address is required")]
        public string? StreetAddress { get; set; }
        public string? AptSuite { get; set; }

        [Required(ErrorMessage = "The city is required")]
        public string? City { get; set; }
        [Required(ErrorMessage = "Province is required")]
        public string? Provicne { get; set; }
        public string? DeliveryInstruction { get; set; }

        public int MemberId { get; set; }
        public Member Member { get; set; } = null!;
    }
}
