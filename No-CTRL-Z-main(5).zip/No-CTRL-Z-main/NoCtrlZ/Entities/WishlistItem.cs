﻿namespace NoCtrlZ.Entities
{
    public class WishlistItem
    {
        public int WishlistItemId { get; set; }
        public int MemberId { get; set; }
        public int GameId {  get; set; }
        public Game Game { get; set; }
        public Member Member { get; set; }

    }
}
