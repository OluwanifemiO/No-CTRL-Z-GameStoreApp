﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace NoCtrlZ.Entities
{
    public class Preference
    {
        public int PreferenceId { get; set; }
        public string? Platform { get; set; }
        public string? GameCategory { get; set; }
        public string? Language { get; set; }

        public int? MemberId { get; set; }
        public Member? Member { get; set; } = null!;
    }
}
