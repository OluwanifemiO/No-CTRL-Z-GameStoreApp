﻿using Microsoft.EntityFrameworkCore;
using System.Web.Helpers;

namespace NoCtrlZ.Entities
{
    public class NoCtrlZDbContext : DbContext
    {
        public NoCtrlZDbContext(DbContextOptions<NoCtrlZDbContext> options)
            : base(options)
        {
        }

        public DbSet<Member> Members { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<WishlistItem> WishlistItems { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<FriendList> FriendList { get; set; }
        public DbSet<FamilyList> FamilyList { get; set; }

        public DbSet<Preference> Prefernces { get; set; }
        public DbSet<Address> Addresses { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Event>().HasMany(e => e.Members).WithMany(e => e.Events);

           
            // create default user
            modelBuilder.Entity<Member>().HasData(
                new Member() { MemberId = 1, Email = "user1@example.com", Password = "!a123456", Username="Samuel123", FirstName = "Samuel", LastName="Brick", PhoneNumber = "(123) 123-1234", IsValidated = true },
                new Member() { MemberId = 2, Email = "user2@example.com", Password = "!a123456", Username= "Julia123", FirstName= "Julia", LastName = "Son", PhoneNumber = "(333) 333-3333", IsValidated = true }
            );

            modelBuilder.Entity<FriendList>().HasData(
                new FriendList() { FriendListId = 1, MemberId = 1, FriendId = 2 },
                new FriendList() { FriendListId = 2, MemberId = 2, FriendId = 1 }
            );

            // create default user
            modelBuilder.Entity<FamilyList>().HasData(
                new FamilyList() { FamilyListId = 1, MemberId = 1, FamilyId = 2 },
                new FamilyList() { FamilyListId = 2, MemberId = 2, FamilyId = 1 }
            );

            // create default address
            modelBuilder.Entity<Address>().HasData(
                new Address() { AddressId = 1, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Samuel", LastName = "Brick", PhoneNumber = "(123) 123-1234", IsDefault = true, Provicne = "ON", StreetAddress = "123 Street", MemberId = 1 },
                new Address() { AddressId = 2, City = "Waterloo", Country = "Canada", DeliveryInstruction = "Leave at door", FirstName = "Julia", LastName = "Son", PhoneNumber = "(123) 123-1234", IsDefault = true, Provicne = "ON", StreetAddress = "123 Street", MemberId = 2 }
            );

            // create default platform
            modelBuilder.Entity<Preference>().HasData(
                new Preference() { PreferenceId = 1, GameCategory = "Action", Language = "English", Platform = "Windows", MemberId = 1 },
                new Preference() { PreferenceId = 2, GameCategory = "Action", Language = "English", Platform = "Windows", MemberId = 2 }
            );

            modelBuilder.Entity<Game>().HasData(
                new Game()
                {
                    GameId = 1,
                    Name = "Call of Duty: Warzone",
                    Description = "Call of Duty: Warzone is a free-to-play battle royale video game developed and published by Activision. It is a part of the popular Call of Duty franchise. Set in the fictional city of Verdansk, Warzone features a massive and highly detailed map that hosts intense 150-player battles. Players drop onto the map from an aircraft, gather weapons, and fight to be the last one standing. The game also includes various game modes, such as Plunder, which focuses on collecting cash, and Rebirth Island, a more compact map with faster-paced action. Call of Duty: Warzone has gained a massive following and continues to receive updates and new content, making it a cornerstone of the battle royale genre.",
                    Price = 59.99,
                    ImagePath = "https://cdn.vox-cdn.com/thumbor/vaxceW8rblopSUP-KfGVcVewJYs=/0x0:1920x1080/920x613/filters:focal(760x73:1066x379):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/71628386/ss_90a18c1fe401fa7174b9cd712133f8a3af58a3ca.0.jpg"
                },
                new Game() 
                { 
                    GameId =2,
                    Name = "The Witcher 3: Wild Hunt",
                    Description = "The Witcher 3: Wild Hunt is an action role-playing game developed and published by CD Projekt. It is based on the book series of the same name by Polish author Andrzej Sapkowski.",
                    Price = 49.99,
                    ImagePath = "https://media.distractify.com/brand-img/ms9mYQprh/1440x753/the-witcher-3-1648132183825.jpg"
                },
                new Game()
                {
                    GameId = 3,
                    Name = "Escape from Tarkov",
                    Description = "Escape from Tarkov is a hardcore and realistic online first-person action RPG/Simulator with MMO features and a story-driven walkthrough. It is developed by Battlestate Games.",
                    Price = 39.99,
                    ImagePath = "https://sim590.github.io/images/Escape-from-Tarkov-header.jpg"
                },
                new Game()
                {
                    GameId = 4,
                    Name = "Battlefield V",
                    Description = "Battlefield V is a first-person shooter video game developed by EA DICE and published by Electronic Arts. It is the sixteenth installment in the Battlefield series.",
                    Price = 49.99,
                    ImagePath = "https://www.trustedreviews.com/wp-content/uploads/sites/54/2021/06/Battlefield-2042-scaled-e1623227856717-920x612.jpg"
                },
                new Game()
                {
                    GameId = 5,
                    Name = "FIFA23",
                    Description = "FIFA 23 is the latest installment in the popular FIFA series developed by Electronic Arts. It features realistic football gameplay, updated player rosters, enhanced graphics, and a range of game modes including Career Mode, Ultimate Team, and more.",
                    Price = 99.99,
                    ImagePath = "https://library.sportingnews.com/styles/crop_style_16_9_desktop/s3/2022-08/kk.jpg?itok=usxtjVyg"
                }

            );

            modelBuilder.Entity<WishlistItem>().HasData(
                new WishlistItem
                {
                    WishlistItemId = 1,
                    GameId = 1, 
                    MemberId = 2,
                },
                new WishlistItem
                {
                    WishlistItemId = 2,
                    GameId = 2, 
                    MemberId = 2, 
                }
            );

            modelBuilder.Entity<Event>().HasData(
                new Event()
                {
                    EventId = 1,
                    Name = "COD Tournament",
                    Description = "1000 players",
                    Date = new DateTime(2023, 10, 15),
                    EmployeeId = 1,
                },
                new Event()
                {
                    EventId = 2,
                    Name = "Tarkov Tournament",
                    Description = "99 players",
                    Date = new DateTime(2023, 11, 1),
                    EmployeeId = 1
                }
            );
            modelBuilder.Entity<Review>().HasData(
                new Review()
                {
                    ReviewId = 1,
                    ReviewText = "Great game!",
                    ApprovalStatus = true,
                    GameId = 1,
                    UserId = 1,
                    EmployeeId = 1
                },
                new Review()
                {
                    ReviewId = 2,
                    ReviewText = "Needs improvement.",
                    ApprovalStatus = false,
                    GameId = 1,
                    UserId = 2,
                    EmployeeId = 1
                }
            );

            modelBuilder.Entity<Employee>().HasData(
                new Employee()
                {
                    EmployeeId = 1,
                    Username="John123",
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "qwe@qwe.qwe",
                    Password = "qwe"
                },
                new Employee()
                {
                    EmployeeId = 2,
                    Username="Jane123",
                    FirstName = "Jane",
                    LastName = "Smith",
                    Email = "jane.smith@example.com",
                    Password = "password456"
                }
            );
        }
    }
}
