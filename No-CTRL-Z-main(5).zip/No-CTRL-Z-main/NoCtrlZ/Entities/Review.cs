﻿namespace NoCtrlZ.Entities
{
    public class Review
    {
        public int ReviewId { get; set; }
        public string ReviewText { get; set; }
        public bool ApprovalStatus { get; set; }
        public int GameId { get; set; }
        public int UserId { get; set; }
        public int EmployeeId { get; set; }

        // Navigation properties
        public Game Game { get; set; }
        public Member User { get; set; }
        public Employee Employee { get; set; }
    }
}
