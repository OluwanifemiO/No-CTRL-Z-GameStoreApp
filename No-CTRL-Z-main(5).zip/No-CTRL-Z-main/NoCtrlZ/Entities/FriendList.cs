﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NoCtrlZ.Entities
{
    public class FriendList
    {
        public int FriendListId { get; set; }
        public int MemberId { get; set; }
        public int FriendId { get; set; }
    }
}
