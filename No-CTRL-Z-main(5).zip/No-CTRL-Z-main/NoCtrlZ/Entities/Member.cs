﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using NoCtrlZ.Validators;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Configuration;

namespace NoCtrlZ.Entities
{
    [Index(nameof(Member.Username), IsUnique = true)]
    public class Member
    {
        public int MemberId { get; set; }

        [Required(ErrorMessage = "The Email is required")]
        [EmailAddress(ErrorMessage="The email is not valid")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "The password is required")]
        [StringLength(15, ErrorMessage = "Must be between 8 and 15 characters", MinimumLength = 8)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,15}$", ErrorMessage= "Password required at least lowercase, uppercase, special case and number\n Must be between 8 and 15 characters")]
        public string? Password { get; set; }

        [NotMapped]
        [Compare(nameof(Password), ErrorMessage = "Confirm password is not matched")]
        public string? ConfirmPassword { get; set; }

        [Required(ErrorMessage = "The username is required")]
        public string? Username { get; set; }

        [Required(ErrorMessage = "The first name is required")]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "The last name is required")]
        public string? LastName { get; set; }

        [RegularExpression("^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]\\d{3}[\\s.-]\\d{4}$", ErrorMessage = "Phone number is not valid")]
        public string? PhoneNumber { get; set; }

        public bool? IsValidated { get; set; }

        [DateLessThanOrEqualToToday]
        public DateTime? Birthdate { get; set; }

        public string? Gender { get; set; }

        public bool PromotionEmail { get; set; }

        public Preference? Prefernce { get; set; }

        public List<Event> Events { get; set; } = new();

        public List<Address> Addresses { get; set; } = new();
    }
}
