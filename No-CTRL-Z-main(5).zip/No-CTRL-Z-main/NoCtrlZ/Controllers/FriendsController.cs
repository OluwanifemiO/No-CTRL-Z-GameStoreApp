﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.SimpleEmail.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{
    public class FriendsController : Controller
    {
        private readonly NoCtrlZDbContext _context;

        public FriendsController(NoCtrlZDbContext context)
        {
            _context = context;
        }

        // GET: FriendList
        public async Task<IActionResult> Index()
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);

            List<FriendList> friendList = _context.FriendList.Where((f) => f.MemberId == memberId).ToList();
            List<Member> friends = new List<Member>();

            friendList.ForEach((f) => {
                var friend = _context.Members.FirstOrDefault((m) => m.MemberId == f.FriendId);
                friends.Add(friend);
            });

            return View("Index", friends);
        }

        public async Task<IActionResult> Find(string search)
        {
            List<Member> members = new List<Member>();
            if (!string.IsNullOrEmpty(search))
            {
                members = _context.Members.Where(m => m.Username.Contains(search)).ToList();
            }


            return View(members);
        }

        public async Task<IActionResult> AddFriend(int id)
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);
            List<FriendList> friend = _context.FriendList.Where((m) => m.MemberId == memberId && m.FriendId == id).ToList();

            if (friend.Count > 0)
            {
                TempData["ErrorMessage"] = "The user is already existed in friend list";
                return RedirectToAction("Index");
            }

            if (memberId == id)
            {
                TempData["ErrorMessage"] = "You cannot add yourself in friend list";
                return RedirectToAction("Index");
            }

            _context.FriendList.Add(new FriendList() { MemberId = memberId, FriendId = id });
            await _context.SaveChangesAsync();
            @TempData["SuccessMessage"] = "Friend is added";

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> DeleteFriend(int id)
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);
            FriendList friend = _context.FriendList.FirstOrDefault((m) => m.MemberId == memberId && m.FriendId == id);
            _context.FriendList.Remove(friend);
            await _context.SaveChangesAsync();
            @TempData["SuccessMessage"] = "The Friend is deleted";

            return RedirectToAction("Index");
        }

       
        // GET: FriendList/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Members == null)
            {
                return NotFound();
            }

            var member = await _context.Members
                .FirstOrDefaultAsync(m => m.MemberId == id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }

        // GET: FriendList/Create
        public IActionResult Create()
        {
            string message = "1234";
            return View("Create", message);
        }

        // POST: FriendList/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MemberId,Email,Password,Username,FirstName,LastName,PhoneNumber,IsValidated,Birthdate,Gender,PromotionEmail")] Member member)
        {
            if (ModelState.IsValid)
            {
                _context.Add(member);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(member);
        }

        // GET: FriendList/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Members == null)
            {
                return NotFound();
            }

            var member = await _context.Members.FindAsync(id);
            if (member == null)
            {
                return NotFound();
            }
            return View(member);
        }

        // POST: FriendList/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MemberId,Email,Password,Username,FirstName,LastName,PhoneNumber,IsValidated,Birthdate,Gender,PromotionEmail")] Member member)
        {
            if (id != member.MemberId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(member);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MemberExists(member.MemberId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(member);
        }

        // GET: FriendList/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Members == null)
            {
                return NotFound();
            }

            var member = await _context.Members
                .FirstOrDefaultAsync(m => m.MemberId == id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }

        // POST: FriendList/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Members == null)
            {
                return Problem("Entity set 'NoCtrlZDbContext.Members'  is null.");
            }
            var member = await _context.Members.FindAsync(id);
            if (member != null)
            {
                _context.Members.Remove(member);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MemberExists(int id)
        {
          return (_context.Members?.Any(e => e.MemberId == id)).GetValueOrDefault();
        }
    }
}
