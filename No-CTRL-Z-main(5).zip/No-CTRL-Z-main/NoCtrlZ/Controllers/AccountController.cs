﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NoCtrlZ.Entities;

using Amazon.SimpleEmail;
using Amazon;
using Amazon.SimpleEmail.Model;
using System.Text.RegularExpressions;
using System.Data;
using System.Net.Mail;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;

namespace NoCtrlZ.Controllers
{
    public class AccountController : Controller
    {
        private NoCtrlZDbContext _dbContext;
        private AmazonSimpleEmailServiceClient awsClient;
        public AccountController(NoCtrlZDbContext dbContext)
        {
            _dbContext = dbContext;
            awsClient = new AmazonSimpleEmailServiceClient("AKIAT4AMDSMCB5WKPLEQ", "/zYXUqdzYwo/7OZ5dYa1USzSeB7ccUNiHNxJut9v", new AmazonSimpleEmailServiceConfig { RegionEndpoint = RegionEndpoint.CACentral1 });
        }

        public IActionResult Login(IFormCollection collection)
        {
            return View();
        }

        public IActionResult Logout(IFormCollection collection)
        {
            HttpContext.Session.Clear();
            // Delete all cookies
            foreach (var cookie in Request.Cookies.Keys)
            {
                Response.Cookies.Delete(cookie);
            }

            return View("Login");
        }

        public ActionResult ValidateEmail()
        {
            return View();
        }

        public ActionResult ValidateCode(IFormCollection collection)
        {
            int memberId = int.Parse(collection["MemberId"]!);
            Member member = _dbContext.Members.Find(memberId)!;
            if (collection["ValidationCode"].ToString() != "12345")
            {
                TempData["error"] = "validate code is not correct";
                return View("ValidateEmail", member);
            }

            member.IsValidated = true;
            _dbContext.Members.Update(member);
            _dbContext.SaveChanges();

            HttpContext.Session.SetString("FailedAttemps", "0");
            HttpContext.Session.SetString("role", "member");
            HttpContext.Session.SetString("memberId", member.MemberId.ToString());
            //employee role cookie
            Response.Cookies.Append("role", "member", new CookieOptions
            {
                Expires = DateTimeOffset.Now.AddHours(1), // Set expiration time 1h
                HttpOnly = true // Ensures the cookie is not accessible through JavaScript
            });
            //employee id cookie
            HttpContext.Session.SetString("memberId", member.MemberId.ToString());
            Response.Cookies.Append("memberId", member.MemberId.ToString(), new CookieOptions
            {
                Expires = DateTimeOffset.Now.AddHours(1), // Set expiration time 1h
                HttpOnly = true // Ensures the cookie is not accessible through JavaScript
            });

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public IActionResult LoginSubmit(IFormCollection collection)
        {
            string? failedAttempt = HttpContext.Session.GetString("FailedAttemps")?.ToString();
            int failedAttemptNo = 0;
            if (failedAttempt == null)
            {
                HttpContext.Session.SetString("FailedAttemps", "0");
            }
            else
            {
                failedAttemptNo = Int32.Parse(failedAttempt);
            }

            if (failedAttemptNo > 3)
            {
                TempData["error"] = "Consecutive failed attempts Try again";
                HttpContext.Session.SetString("FailedAttemps", "0");
                return View("login");
            }


            if (collection["Role"].Equals("Employee"))
            {
                // sucess login
                Employee? employee = _dbContext.Employees.Where(u => u.Username == collection["Username"].ToString()).FirstOrDefault();

                if (employee == null)
                {
                    failedAttemptNo++;
                    HttpContext.Session.SetString("FailedAttemps", failedAttemptNo.ToString());
                        TempData["error"] = "email or password incorrect";
                    return View("login");
                }

                if (employee.Password != collection["password"])
                {
                    failedAttemptNo++;
                    HttpContext.Session.SetString("FailedAttemps", failedAttemptNo.ToString());
                    TempData["error"] = "email or password incorrect";
                    return View("login");
                }

                HttpContext.Session.SetString("FailedAttemps", "0");
                HttpContext.Session.SetString("role", "employee");
                //employee role cookie
                Response.Cookies.Append("role", "employee", new CookieOptions
                {
                    Expires = DateTimeOffset.Now.AddHours(1), // Set expiration time 1h
                    HttpOnly = true // Ensures the cookie is not accessible through JavaScript
                });
                //employee id cookie
                HttpContext.Session.SetString("employeeId", employee.EmployeeId.ToString());
                Response.Cookies.Append("employeeId", employee.EmployeeId.ToString(), new CookieOptions
                {
                    Expires = DateTimeOffset.Now.AddHours(1), // Set expiration time 1h
                    HttpOnly = true // Ensures the cookie is not accessible through JavaScript
                });

                return RedirectToAction("Index", "Home");
            }

            if (collection["Role"].Equals("Member"))
            {
                // sucess login
                Member? member = _dbContext.Members.Where(u => u.Username == collection["Username"].ToString()).FirstOrDefault();

                if (member == null)
                {
                    failedAttemptNo++;
                    HttpContext.Session.SetString("FailedAttemps", failedAttemptNo.ToString());
                    TempData["error"] = "email or password incorrect";
                    return View("login");
                }

                if (member.Password != collection["password"])
                {
                    failedAttemptNo++;
                    HttpContext.Session.SetString("FailedAttemps", failedAttemptNo.ToString());
                    TempData["error"] = "email or password incorrect";
                    return View("login");
                }

                if (member.IsValidated != true)
                {
                    return View("ValidateEmail", member);
                }

                HttpContext.Session.SetString("FailedAttemps", "0");
                HttpContext.Session.SetString("role", "member");
                HttpContext.Session.SetString("memberId", member.MemberId.ToString());
                //employee role cookie
                Response.Cookies.Append("role", "member", new CookieOptions
                {
                    Expires = DateTimeOffset.Now.AddHours(1), // Set expiration time 1h
                    HttpOnly = true // Ensures the cookie is not accessible through JavaScript
                });
                //employee id cookie
                HttpContext.Session.SetString("memberId", member.MemberId.ToString());
                Response.Cookies.Append("memberId", member.MemberId.ToString(), new CookieOptions
                {
                    Expires = DateTimeOffset.Now.AddHours(1), // Set expiration time 1h
                    HttpOnly = true // Ensures the cookie is not accessible through JavaScript
                });


                return RedirectToAction("Index", "Home");
            }

            return RedirectToAction("Login");
        }

        public IActionResult Register()
        {
            ViewBag.MathCaptcha = GenerateMathCaptcha();
            return View();
        }

        public IActionResult Forget()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RegisterSubmit(IFormCollection collection, [Bind("MemberId,Email,Password,ConfirmPassword,Username,FirstName,LastName,PhoneNumber,IsValidated,Birthdate,Gender,PromotionEmail")] Member member) 
        {
            //Math Captcha Logic
            string mathCaptchaInput = collection["mathCaptchaInput"];
            string storedMathCaptcha = GetMathCaptchaFromCookie();

            int result = (int)new DataTable().Compute(storedMathCaptcha, null);

            if (!mathCaptchaInput.Equals(result.ToString()))
            {
                TempData["error"] = "CAPTCHA validation failed. Please try again.";
                ViewBag.MathCaptcha = GenerateMathCaptcha();

                return View("Register", member);
            }

            if (!ModelState.IsValid)
            {
                ViewBag.MathCaptcha = GenerateMathCaptcha();

                return View("Register", member);
            }

            var existedMember = _dbContext.Members.Where(m => m.Username == member.Username).ToList();
            if (existedMember.Count != 0)
            {
                ViewBag.MathCaptcha = GenerateMathCaptcha();

                ModelState.AddModelError(nameof(member.Username), "User name is already registered");
                return View("Register", member);
            }
            
            member.Prefernce = new Preference() { GameCategory = "N/A", Language = "N/A", Platform = "N/A" };
            
            _dbContext.Add(member);
            await _dbContext.SaveChangesAsync();
       
            MailMessage msg = new MailMessage("jjoo08154@gmail.com", member.Email!,
                "No CTRL Z new user is required to validate", "Your validation code is 12345");
            msg.SubjectEncoding = Encoding.UTF8;
            msg.BodyEncoding = Encoding.UTF8;

            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = "smtp.gmail.com";
            smtpClient.Port = 587;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Credentials = new System.Net.NetworkCredential("jjoo08154", "zktd gbsf bczw ewcw");
            smtpClient.EnableSsl = true;

            smtpClient.Send(msg);
            msg.Dispose();

            TempData["error"] = "Validation code is sent to your email";

            return View("Login");
        }

        [HttpPost]
        public IActionResult ForgetPassword(IFormCollection collection)
        {
            var user = _dbContext.Members.Where(u => u.Username == collection["Username"].ToString()).FirstOrDefault();
            if (user == null)
            {
                TempData["error"] = "Username does not exist";
                return View("Forget");
            }

            TempData["error"] = "New password is sent to your email";

            //var sendRequest = new SendEmailRequest
            //{
            //    Source = "NoCtrlZ@groundkim.com",
            //    Destination = new Destination
            //    {
            //        ToAddresses = new List<string> { user.Email! }
            //    },
            //    Message = new Message
            //    {
            //        Subject = new Content("No CTRL Z password is reset"),
            //        Body = new Body
            //        {
            //            Html = new Content
            //            {
            //                Charset = "UTF-8",
            //                Data = "The new password is !a123456"
            //            }
            //        }
            //    }
            //};

            MailMessage msg = new MailMessage("jjoo08154@gmail.com", user.Email!,
                "No CTRL Z password is reset", "The new password is !a123456");
            msg.SubjectEncoding = Encoding.UTF8;
            msg.BodyEncoding = Encoding.UTF8;

            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = "smtp.gmail.com";
            smtpClient.Port = 587;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Credentials = new System.Net.NetworkCredential("jjoo08154", "zktd gbsf bczw ewcw");
            smtpClient.EnableSsl = true;

            smtpClient.Send(msg);
            msg.Dispose();

            //awsClient.SendEmailAsync(sendRequest);

            user.Password = "!a123456";
            _dbContext.Members.Update(user);
            _dbContext.SaveChanges();

            return View("Login");
        }


        private string GetMathCaptchaFromCookie()
        {
            return Request.Cookies["MathCaptcha"];
        }

        private void SetMathCaptchaCookie(string mathCaptcha)
        {
            Response.Cookies.Append("MathCaptcha", mathCaptcha, new CookieOptions
            {
                Expires = DateTimeOffset.Now.AddMinutes(30), 
                HttpOnly = true
            });
        }

        private string GenerateMathCaptcha()
        {
            Random random = new Random();
            int operand1 = random.Next(1, 10);
            int operand2 = random.Next(1, 10);
            char[] operators = { '+', '-', '*' };
            char selectedOperator = operators[random.Next(operators.Length)];

            string mathExpression = $"{operand1} {selectedOperator} {operand2}";

            SetMathCaptchaCookie(mathExpression);

            return mathExpression;
        }
    }
}
