﻿using Microsoft.AspNetCore.Mvc;
using NoCtrlZ.Entities;
using NoCtrlZ.Models;

namespace NoCtrlZ.Controllers
{
    public class ManageEventController : Controller
    {
        private NoCtrlZDbContext db;

        public ManageEventController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        // GET: ManageEvent
        public ActionResult Index()
        {
            if (Request.Cookies.TryGetValue("role", out string role) && role == "employee")
            {
                if (Request.Cookies.TryGetValue("employeeId", out string employeeId))
                {
                    // Both "role" and "employeeId" cookies exist
                    List<Event> events = db.Events.ToList();
                    return View(events);
                }
            }

            // If any of the cookies are missing or the role is not "employee", redirect to login
            return RedirectToAction("Login", "Account");
            
        }

        public ActionResult Create()
        {
            return View();
        }
        public ActionResult Details(int id)
        {
            Event selectedEvent = db.Events.Find(id);

            if (selectedEvent == null)
            {
                return NotFound();
            }

            return View(selectedEvent);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Event @event)
        {
            if (ModelState.IsValid)
            {
                int employeeId = int.Parse(HttpContext.Session.GetString("employeeId"));

                @event.EmployeeId = employeeId;
                db.Events.Add(@event);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(@event);
        }

        public ActionResult Edit(int id)
        {
            Event @event = db.Events.Find(id);

            if (@event == null)
            {
                return HttpNotFound();
            }

            return View(@event);
        }

        private ActionResult HttpNotFound()
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Event @event)
        {
            if (ModelState.IsValid)
            {
                int employeeId = int.Parse(HttpContext.Session.GetString("employeeId"));

                @event.EmployeeId = employeeId;

                db.Events.Update(@event);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(@event);
        }

        public ActionResult Delete(int id)
        {
            Event @event = db.Events.Find(id);

            if (@event == null)
            {
                return HttpNotFound();
            }

            return View(@event);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Event @event = db.Events.Find(id);
            db.Events.Remove(@event);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
