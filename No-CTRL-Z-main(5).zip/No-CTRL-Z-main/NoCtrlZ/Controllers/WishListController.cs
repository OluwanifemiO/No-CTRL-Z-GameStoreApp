﻿using Microsoft.AspNetCore.Mvc;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{
    public class WishListController : Controller
    {
        private NoCtrlZDbContext db;

        public WishListController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        public IActionResult Index()
        {
            string memberId = Request.Cookies["memberId"];

            

            if (!string.IsNullOrEmpty(memberId))
            {
                int memberIdValue;
                if (int.TryParse(memberId, out memberIdValue))
                {
                    Member member = db.Members.FirstOrDefault(m => m.MemberId == memberIdValue);

                    if (member != null)
                    {
                        // Retrieve the wishlist items for the logged-in member
                        var wishlistItems = db.WishlistItems
                            .Where(item => item.MemberId == int.Parse(memberId))
                            .ToList();

                        var gameIds = wishlistItems.Select(item => item.GameId).ToList();

                        var gamesInWishlist = db.Games
                            .Where(game => gameIds.Contains(game.GameId))
                            .ToList();

                        return View("Index", gamesInWishlist);
                    }
                }
            }
            // If any of the cookies are missing or the role is not "employee", redirect to login

            return RedirectToAction("Login", "Account");
        }

        [HttpPost]
        public IActionResult RemoveFromWishlist(int id)
        {
            string memberId = Request.Cookies["memberId"];

            if (!string.IsNullOrEmpty(memberId))
            {
                int memberIdValue;
                if (int.TryParse(memberId, out memberIdValue))
                {
                    WishlistItem wishlistItem = db.WishlistItems.FirstOrDefault(item =>
                        item.MemberId == memberIdValue && item.GameId == id);

                    if (wishlistItem != null)
                    {
                        db.WishlistItems.Remove(wishlistItem);
                        db.SaveChanges();
                        return RedirectToAction("Index", "Wishlist");
                    }
                }
            }

            return RedirectToAction("Login", "Account");
        }
    }
}
