﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;
using Game = NoCtrlZ.Entities.Game;

namespace NoCtrlZ.Controllers
{
    public class ManageGameController : Controller
    {
        private NoCtrlZDbContext db;

        public ManageGameController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        // GET: Game
        public ActionResult Index()
        {
            if (Request.Cookies.TryGetValue("role", out string role) && role == "employee")
            {
                if (Request.Cookies.TryGetValue("employeeId", out string employeeId))
                {
                    // Both "role" and "employeeId" cookies exist
                    List<Game> games = db.Games.ToList();
                    return View(games);
                }
            }

            // If any of the cookies are missing or the role is not "employee", redirect to login
            return RedirectToAction("Login", "Account");
            
        }

        // GET: ManageGame/Details/id
        public ActionResult Details(int id)
        {
            Game game = db.Games.Find(id);

            if (game == null)
            {
                return HttpNotFound();
            }

            return View(game);
        }

        private ActionResult HttpNotFound()
        {
            throw new NotImplementedException();
        }

        // GET: Game/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Game/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Game game)
        {
            if (ModelState.IsValid)
            {
                db.Games.Add(game);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(game);
        }

        // GET: Game/Edit/5
        public ActionResult Edit(int id)
        {
            Game game = db.Games.Find(id);

            if (game == null)
            {
                return HttpNotFound();
            }

            return View(game);
        }

        // POST: Game/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Game game)
        {
            if (ModelState.IsValid)
            {
                db.Games.Update(game);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(game);
        }

        // GET: Game/Delete/5
        public ActionResult Delete(int id)
        {
            Game game = db.Games.Find(id);

            if (game == null)
            {
                return HttpNotFound();
            }

            return View(game);
        }

        // POST: Game/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Game game = db.Games.Find(id);
            db.Games.Remove(game);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
