﻿using Microsoft.AspNetCore.Mvc;

namespace NoCtrlZ.Controllers
{
    public class ReportController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
