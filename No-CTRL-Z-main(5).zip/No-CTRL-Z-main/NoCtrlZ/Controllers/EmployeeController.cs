﻿using Microsoft.AspNetCore.Mvc;

namespace NoCtrlZ.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public IActionResult Index()
        {
            if (Request.Cookies.TryGetValue("role", out string role) && role == "employee")
            {
                if (Request.Cookies.TryGetValue("employeeId", out string employeeId))
                {
                    // Both "role" and "employeeId" cookies exist

                    return View();
                }
            }

            // If any of the cookies are missing or the role is not "employee", redirect to login
            return RedirectToAction("Login", "Account");
        }


    }
}
