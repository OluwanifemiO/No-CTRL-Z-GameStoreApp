﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{
    public class AddressesController : Controller
    {
        private readonly NoCtrlZDbContext _context;

        public AddressesController(NoCtrlZDbContext context)
        {
            _context = context;
        }

        // GET: Addresses
        public async Task<IActionResult> Index()
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);

            var addresses = _context.Addresses.Where((a) => a.MemberId == memberId).ToList();
            return View("Index" ,addresses);
        }

        // GET: Addresses/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Addresses == null)
            {
                return NotFound();
            }

            var address = await _context.Addresses
                .Include(a => a.Member)
                .FirstOrDefaultAsync(m => m.AddressId == id);
            if (address == null)
            {
                return NotFound();
            }

            return View(address);
        }

        // GET: Addresses/Create
        public IActionResult Create()
        {
            ViewData["MemberId"] = new SelectList(_context.Members, "MemberId", "MemberId");
            return View();
        }

        // POST: Addresses/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AddressId,IsDefault,Country,FirstName,LastName,PhoneNumber,StreetAddress,AptSuite,City,Provicne,DeliveryInstruction,MemberId")] Address address)
        {
            ModelState.Remove("Member");
            if (ModelState.IsValid)
            {
                int memberId = Int32.Parse(Request.Cookies["memberId"]!);
                address.MemberId = memberId;
                _context.Add(address);
                await _context.SaveChangesAsync();


                TempData["SuccessMessage"] = "New address is created!";

                return RedirectToAction(nameof(Index));
            }
            ViewData["MemberId"] = new SelectList(_context.Members, "MemberId", "MemberId", address.MemberId);
            return View(address);
        }

        // GET: Addresses/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Addresses == null)
            {
                return NotFound();
            }

            var address = _context.Addresses.Include(a => a.Member).FirstOrDefault(a => a.AddressId == id);
            
            if (address == null)
            {
                return NotFound();
            }
            ViewData["MemberId"] = new SelectList(_context.Members, "MemberId", "MemberId", address.MemberId);
            return View(address);
        }

        public async Task<IActionResult> ChangeDefaultAddress(int id)
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);
            var address = _context.Addresses.Where(a => a.MemberId == memberId).ToList();
            address.ForEach(a => a.IsDefault = false);
            _context.SaveChanges();

            var a = _context.Addresses.FirstOrDefault(a => a.AddressId == id);
            a.IsDefault = true;
            _context.SaveChanges();

            TempData["SuccessMessage"] = "The default address is changed";

            return RedirectToAction("Index");
        }

        // POST: Addresses/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AddressId,IsDefault,Country,FirstName,LastName,PhoneNumber,StreetAddress,AptSuite,City,Provicne,DeliveryInstruction,MemberId")] Address address)
        {
            if (id != address.AddressId)
            {
                return NotFound();
            }

            ModelState.Remove("Member");
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(address);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AddressExists(address.AddressId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                TempData["SuccessMessage"] = "The address is updated";
                return RedirectToAction(nameof(Index));
            }
            ViewData["MemberId"] = new SelectList(_context.Members, "MemberId", "MemberId", address.MemberId);
            return View(address);
        }

        // GET: Addresses/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            //if (id == null || _context.Addresses == null)
            //{
            //    return NotFound();
            //}

            //var address = await _context.Addresses
            //    .Include(a => a.Member)
            //    .FirstOrDefaultAsync(m => m.AddressId == id);
            //if (address == null)
            //{
            //    return NotFound();
            //}

            //return View(address);

            if (_context.Addresses == null)
            {
                return Problem("Entity set 'NoCtrlZDbContext.Addresses'  is null.");
            }
            var address = await _context.Addresses.FindAsync(id);
            if (address != null)
            {
                _context.Addresses.Remove(address);
            }
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "The address is deleted";
            return RedirectToAction(nameof(Index));
        }

        // POST: Addresses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Addresses == null)
            {
                return Problem("Entity set 'NoCtrlZDbContext.Addresses'  is null.");
            }
            var address = await _context.Addresses.FindAsync(id);
            if (address != null)
            {
                _context.Addresses.Remove(address);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AddressExists(int id)
        {
          return (_context.Addresses?.Any(e => e.AddressId == id)).GetValueOrDefault();
        }
    }
}
