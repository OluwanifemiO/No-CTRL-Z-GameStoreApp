﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{
    public class EventController : Controller
    {
        private NoCtrlZDbContext db;

        public EventController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        // GET: Event
        public ActionResult Index()
        {
            List<Event> events = db.Events.Include(e => e.Members).ToList();
            return View(events);
        }

        public ActionResult Detail(int EventId)
        {
            Event e = db.Events.Include(e => e.Members).Where(e => e.EventId == EventId).First();
            return View(e);
        }

        public ActionResult RegisterMember(int EventId) 
        {
            Request.Cookies.TryGetValue("memberId", out string strMemberId);
            int memberId = int.Parse(strMemberId);
            Member member = db.Members.Find(memberId)!;

            db.Events.Find(EventId)!.Members.Add(member);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
