﻿using Amazon.SimpleEmail.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;
using System.Security.Claims;

namespace NoCtrlZ.Controllers
{
    public class GameController : Controller
    {
        private NoCtrlZDbContext db;
        public GameController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        // GET: Game
        public ActionResult Index(string search)
        {
            List<Game> games;

            if (!string.IsNullOrEmpty(search))
            {
                games = db.Games.Where(g => g.Name.Contains(search)).ToList();
            }
            else
            {
                games = db.Games.ToList();
            }

            return View(games);
        }

        public ActionResult Details(int id)
        {
            Game game = db.Games.Find(id);


            List<Game> recommendedGames = GetRecommendedGames();

            ViewBag.RecommendedGames = recommendedGames;

            return View(game);
        }
        public List<Game> GetRecommendedGames()
        {
            List<Game> recommendedGames = db.Games.OrderBy(g => Guid.NewGuid()).Take(4).ToList();
            return recommendedGames;
        }

        [HttpPost]
        public IActionResult AddToWishlist(int id)
        {
            string memberId = Request.Cookies["memberId"];



            if (!string.IsNullOrEmpty(memberId))
            {
                int memberIdValue;
                if (int.TryParse(memberId, out memberIdValue))
                {
                    Member member = db.Members.FirstOrDefault(m => m.MemberId == memberIdValue);

                    if (member != null)
                    {
                        // Check if the game is already in the wishlist
                        bool gameAlreadyInWishlist = db.WishlistItems
                            .Any(item => item.MemberId == member.MemberId && item.GameId == id);

                        if (gameAlreadyInWishlist)
                        {
                            // You can handle this case (game already in wishlist) as needed
                            // For example, show a message to the user
                            TempData["ErrorMessage"] = "This game is already in your wishlist.";
                            return RedirectToAction("Index", "Game");

                        }
                        else
                        {
                            // Add the game to the wishlist
                            WishlistItem wishlistItem = new WishlistItem
                            {
                                MemberId = member.MemberId,
                                GameId = id
                            };

                            db.WishlistItems.Add(wishlistItem);
                            db.SaveChanges();

                            TempData["SuccessMessage"] = "Game added to your wishlist.";

                            return RedirectToAction("Index", "Game");
                        }
                    }
                }
            }
            // If any of the cookies are missing or the role is not "employee", redirect to login

            return RedirectToAction("Login", "Account");
        }

        [HttpPost]
        public IActionResult AddToWishlistFromDetail(int id)
        {
            string memberId = Request.Cookies["memberId"];



            if (!string.IsNullOrEmpty(memberId))
            {
                int memberIdValue;
                if (int.TryParse(memberId, out memberIdValue))
                {
                    Member member = db.Members.FirstOrDefault(m => m.MemberId == memberIdValue);

                    if (member != null)
                    {
                        // Check if the game is already in the wishlist
                        bool gameAlreadyInWishlist = db.WishlistItems
                            .Any(item => item.MemberId == member.MemberId && item.GameId == id);

                        if (gameAlreadyInWishlist)
                        {
                            // You can handle this case (game already in wishlist) as needed
                            // For example, show a message to the user
                            TempData["ErrorMessage"] = "This game is already in your wishlist.";
                            

                        }
                        else
                        {
                            // Add the game to the wishlist
                            WishlistItem wishlistItem = new WishlistItem
                            {
                                MemberId = member.MemberId,
                                GameId = id
                            };

                            db.WishlistItems.Add(wishlistItem);
                            db.SaveChanges();

                            TempData["SuccessMessage"] = "Game added to your wishlist.";

                        }
                        return RedirectToAction("Details", "Game", new { id = id });
                    }
                }
            }
            // If any of the cookies are missing or the role is not "employee", redirect to login

            return RedirectToAction("Login", "Account");
        }
    }
}
