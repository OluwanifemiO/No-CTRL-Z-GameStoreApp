﻿using Microsoft.AspNetCore.Mvc;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{

    public class ManageReviewController : Controller
    {
        private NoCtrlZDbContext db;

        public ManageReviewController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        // GET: Review
        public ActionResult Index(bool? approvalStatus)
        {
            
            if (Request.Cookies.TryGetValue("role", out string role) && role == "employee")
            {
                if (Request.Cookies.TryGetValue("employeeId", out string employeeId))
                {
                    // Both "role" and "employeeId" cookies exist
                    IQueryable<Review> reviews = db.Reviews;

                    if (approvalStatus != null)
                    {
                        reviews = reviews.Where(r => r.ApprovalStatus == approvalStatus);
                    }

                    return View(reviews.ToList());
                }
            }

            // If any of the cookies are missing or the role is not "employee", redirect to login
            return RedirectToAction("Login", "Account");
        }

        public ActionResult Approve(int reviewId)
        {
            var review = db.Reviews.Find(reviewId);
            if (review != null)
            {
                review.ApprovalStatus = true;
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        public ActionResult Disapprove(int reviewId)
        {
            var review = db.Reviews.Find(reviewId);
            if (review != null)
            {
                review.ApprovalStatus = false;
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
