﻿using Amazon.SimpleEmail.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;
using NoCtrlZ.Models;
using System.Diagnostics.Metrics;
using System.Drawing.Drawing2D;
using System.Net;
using System.Text.RegularExpressions;

namespace NoCtrlZ.Controllers
{
    public class ProfileController : Controller
    {
        private NoCtrlZDbContext db;

        public ProfileController(NoCtrlZDbContext dbContext)
        {
            db = dbContext;
        }

        IndexModel model;
        string globalTabName = "EditAccount";

        public IActionResult Index()
        {
            string role = Request.Cookies["role"];

            if (string.IsNullOrEmpty(role))
            {
                return RedirectToAction("Login", "Account");
            }

            string employeeId = Request.Cookies["employeeId"];
            string memberId = Request.Cookies["memberId"];

            if (string.IsNullOrEmpty(employeeId) && string.IsNullOrEmpty(memberId))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!string.IsNullOrEmpty(employeeId))
            {
                int employeeIdValue;
                if (int.TryParse(employeeId, out employeeIdValue))
                {
                    Employee employee = db.Employees.FirstOrDefault(e => e.EmployeeId == employeeIdValue);

                    if (employee != null)
                    {
                        return View("Index", employee);
                    }
                }
            }

            if (!string.IsNullOrEmpty(memberId))
            {
                int memberIdValue;
                if (int.TryParse(memberId, out memberIdValue))
                {
                    Member member = db.Members.FirstOrDefault(m => m.MemberId == memberIdValue);

                    if (member != null)
                    {
                        return View("Index", member);
                    }
                }
            }
            // If any of the cookies are missing or the role is not "employee", redirect to login

            return RedirectToAction("Login", "Account");
        }




        // GET: Profile/EditAccount
        public ActionResult EditProfile()
        {
            int memberId = int.Parse(Request.Cookies["memberId"]!);
            Member member = db.Members.Find(memberId)!;

            return View(member);
        }

        public ActionResult EditPassword()
        {
            return View();
        }
        public ActionResult EditPreference()
        {
            int memberId = int.Parse(Request.Cookies["memberId"]!);
            var preference = db.Prefernces.FirstOrDefault(p => p.MemberId == memberId);
            return View("EditPreference", preference);
        }
        public ActionResult EditAccount()
        {
            return View();
        }
        public ActionResult EditPayment()
        {
            return View();
        }
        public ActionResult EditAddress()
        {
            return View();
        }

        public ActionResult EditPasswordSubmit([Bind("OldPassword,NewPassword,ConfirmPassword")] ChangePassword changePassword)
        {
            int memberId = int.Parse(Request.Cookies["memberId"]!);
            Member member = db.Members.Find(memberId)!;

            if (ModelState.IsValid)
            {
                if (member.Password == changePassword.OldPassword)
                {
                    member.Password = changePassword.NewPassword;
                    db.Members.Update(member);
                    db.SaveChanges();
                    TempData["SuccessMessage"] = "Password is changed!";
                    return RedirectToAction("EditPassword");
                }
                else
                {
                    TempData["ErrorMessage"] = "Old password is wrong";
                    return RedirectToAction("EditPassword");
                }
            }

            return RedirectToAction("EditPassword");
        }

        // POST: Profile/EditAccount
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditProfile(Member member)
        {
            if (!ModelState.IsValid)
            {
                return View(member);
            }

            db.Members.Update(member);
            db.SaveChanges();

            return RedirectToAction("Index", "Profile");
        }

        public IActionResult ChangeTab(string tabName)
        {
            
            if (tabName == "EditAccount" || tabName == "EditPayment")
            {
                
                globalTabName = tabName;
                // Update the CurrentTab value in session
                HttpContext.Session.SetString("CurrentTab", globalTabName);

                string currentTab = HttpContext.Session.GetString("currentTab");

                // Redirect to the Index action to refresh the page with the new tab
                return RedirectToAction("Index");
            }

            return BadRequest("Invalid tabName");
        }

    }
}
