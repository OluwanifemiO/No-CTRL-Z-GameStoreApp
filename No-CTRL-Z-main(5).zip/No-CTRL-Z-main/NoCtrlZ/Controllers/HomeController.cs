﻿using Microsoft.AspNetCore.Mvc;
using NoCtrlZ.Entities;
using NoCtrlZ.Models;
using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace NoCtrlZ.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private NoCtrlZDbContext _dbContext;

        public HomeController(ILogger<HomeController> logger, NoCtrlZDbContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            string role = Request.Cookies["role"];

            if (string.IsNullOrEmpty(role))
            {
                return RedirectToAction("Login", "Account");
            }

            string employeeId = Request.Cookies["employeeId"];
            string memberId = Request.Cookies["memberId"];

            if (string.IsNullOrEmpty(employeeId) && string.IsNullOrEmpty(memberId))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!string.IsNullOrEmpty(employeeId))
            {
                int employeeIdValue;
                if (int.TryParse(employeeId, out employeeIdValue))
                {
                    Employee employee = _dbContext.Employees.FirstOrDefault(e => e.EmployeeId == employeeIdValue);

                    if (employee != null)
                    {
                        return View("Index", employee);
                    }
                }
            }

            if (!string.IsNullOrEmpty(memberId))
            {
                int memberIdValue;
                if (int.TryParse(memberId, out memberIdValue))
                {
                    Member member = _dbContext.Members.FirstOrDefault(m => m.MemberId == memberIdValue);

                    if (member != null)
                    {
                        return View("Index", member);
                    }
                }
            }

            return RedirectToAction("Index", "Home");
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}