﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.SimpleEmail.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{
    public class FamiliesController : Controller
    {
        private readonly NoCtrlZDbContext _context;

        public FamiliesController(NoCtrlZDbContext context)
        {
            _context = context;
        }

        // GET: FriendList
        public async Task<IActionResult> Index()
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);

            List<FamilyList> familiyList = _context.FamilyList.Where((f) => f.MemberId == memberId).ToList();
            List<Member> families = new List<Member>();

            familiyList.ForEach((f) => {
                var familiy = _context.Members.FirstOrDefault((m) => m.MemberId == f.FamilyId);
                families.Add(familiy);
            });

            return View("Index", families);
        }

        public async Task<IActionResult> Find(string search)
        {
            List<Member> members = new List<Member>();
            if (!string.IsNullOrEmpty(search))
            {
                members = _context.Members.Where(m => m.Username.Contains(search)).ToList();
            }


            return View(members);
        }

        public async Task<IActionResult> AddFamily(int id)
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);
            List<FamilyList> families = _context.FamilyList.Where((m) => m.MemberId == memberId && m.FamilyId == id).ToList();

            if (families.Count > 0)
            {
                TempData["ErrorMessage"] = "The user is already existed in families list";
                return RedirectToAction("Index");
            }

            if (memberId == id)
            {
                TempData["ErrorMessage"] = "You cannot add yourself in family list";
                return RedirectToAction("Index");
            }

            _context.FamilyList.Add(new FamilyList() { MemberId = memberId, FamilyId = id });
            await _context.SaveChangesAsync();
            @TempData["SuccessMessage"] = "Family is added";

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> DeleteFamily(int id)
        {
            int memberId = Int32.Parse(Request.Cookies["memberId"]!);
            FamilyList family = _context.FamilyList.FirstOrDefault((m) => m.MemberId == memberId && m.FamilyId == id);
            _context.FamilyList.Remove(family);
            await _context.SaveChangesAsync();
            @TempData["SuccessMessage"] = "The Family is deleted";

            return RedirectToAction("Index");
        }

    }
}
