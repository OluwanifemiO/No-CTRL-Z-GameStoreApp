﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.SimpleEmail.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NoCtrlZ.Entities;

namespace NoCtrlZ.Controllers
{
    public class PreferenceController : Controller
    {
        private readonly NoCtrlZDbContext _context;

        public PreferenceController(NoCtrlZDbContext context)
        {
            _context = context;
        }


        [HttpPost]
        public IActionResult EditPreference([Bind("PreferenceId,Platform,GameCategory,Language")] Preference preference)
        {
            int memberId = int.Parse(Request.Cookies["memberId"]!);

            var p = _context.Prefernces.FirstOrDefault(p => p.MemberId == memberId);
            p.Platform = preference.Platform;
            p.Language = preference.Language;
            p.GameCategory = preference.GameCategory;
             
            _context.SaveChanges();
            TempData["SuccessMessage"] = "Preference updated";
            return RedirectToAction("EditPreference", "Profile");
        }
    }
}
